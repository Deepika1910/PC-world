package com.poc.rest.springboot.controller;


import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.logging.Logger;

@RestController
@RequestMapping("/poc")
public class PocController {
    private transient final Logger logger = Logger.getLogger(PocController.class.getName());

    @ResponseStatus(HttpStatus.OK)
    @RequestMapping(method = RequestMethod.GET, produces = "text/html")
    public ResponseEntity<String> heartBeat() {
        logger.fine("Checking HeartBeat of Service API.");
        String response = "Service API Heart Beat........";
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @ResponseStatus(HttpStatus.OK)
    @RequestMapping(method = RequestMethod.POST, consumes = "text/plain")
    public ResponseEntity<String> create(@RequestBody String inputValue) {
        logger.fine("Responding Travel Port With some input..");
        String response = StringUtils.isNotBlank(inputValue) ? "I love Travel Port and would love a job" : "Send some input text";
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
