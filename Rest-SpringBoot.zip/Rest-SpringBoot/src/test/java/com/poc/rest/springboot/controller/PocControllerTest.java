package com.poc.rest.springboot.controller;

import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.*;


public class PocControllerTest {

    PocController pocController = new PocController();

    @Test
    public void heartBeat() throws Exception {
        ResponseEntity<String> response = pocController.heartBeat();

        /** Validate the response object.*/
        assertNotNull(response);
        assertEquals(response.getStatusCode(), HttpStatus.OK);
        assertEquals(response.getBody(), "Service API Heart Beat........");

    }

    @Test
    public void create() throws Exception {
        ResponseEntity<String> response = pocController.create("Hi Travel Port");

        /** Validate the response object.*/
        assertNotNull(response);
        assertEquals(response.getStatusCode(), HttpStatus.OK);
        assertEquals(response.getBody(), "I love Travel Port and would love a job");
    }

}